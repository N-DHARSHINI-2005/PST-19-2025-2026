public class Main {
    public static void main(String[] args) {

        int n = 7;        
        int flag = 0;     

        if (n <= 1) {
            flag = 1;
        } else {
            for (int i = 2; i < n; i++) {
                if (n % i == 0) {
                    flag = 1;
                    break;
                }
            }
        }

        if (flag == 0) {
            System.out.println("Prime Number");
        } else {
            System.out.println("Not a Prime Number");
        }
    }
}
